list_A = {1, 2, 3, 7, 9, 12, 15, 18, 21, 24}
list_B = {4, 5, 6, 10, 11, 13, 16, 19, 22, 25}
my_list = [1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 7, 9, 12, 15, 18, 21, 24, 10, 11, 13, 16, 19, 22, 25, 1, 2, 3, 4, 5]

myHappiness = 0

for num in my_list:
    if num in list_A:
        myHappiness += 1
    elif num in list_B:
        myHappiness -= 1

print("Final Happiness:", myHappiness)
