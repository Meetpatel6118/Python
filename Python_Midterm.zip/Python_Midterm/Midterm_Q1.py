def calculate_tax(income):
    if income <= 30000:
        tax = income * 0.10
    elif income <= 60000:
        tax = 30000 * 0.10 + (income - 30000) * 0.15
    elif income <= 100000:
        tax = 30000 * 0.10 + 30000 * 0.15 + (income - 60000) * 0.20
    else:
        tax = 30000 * 0.10 + 30000 * 0.15 + 40000 * 0.20 + (income - 100000) * 0.25
    return tax


while True:
    hourly_wage = float(input("Please Enter your hourly wage: "))
    if hourly_wage == 0:
        break

    hours_per_week = float(input("Please enter the number of hours worked per week: "))

    annual_income = hourly_wage * hours_per_week * 52
    taxable_income = annual_income - 12000  

    if taxable_income <= 0:
        tax = 0
    else:
        tax = calculate_tax(taxable_income)

    net_income = annual_income - tax

    print(f"Annual Gross Income: ${annual_income:.2f}")
    print(f"Tax: ${tax:.2f}")
    print(f"Net Income: ${net_income:.2f}")
    print()
