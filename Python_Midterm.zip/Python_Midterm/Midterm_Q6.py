import time
import random

def game():
    words = ['python', 'java', 'ruby', 'javascript', 'swift', 'cplusplus', 'html', 'css', 'php', 'kotlin', 'r', 'perl', 'go']
    
    level = int(input("Choose a level (1, 2, or 3): "))
    
    if level == 1:
        max_word_length = 6
        max_time = 8
    elif level == 2:
        max_word_length = 10
        max_time = 8
    elif level == 3:
        max_word_length = float('inf')
        max_time = 8
    else:
        print("Invalid level choice.")
        return

    while True:
        word = random.choice(words)
        if len(word) <= max_word_length:
            break

    print("Type the word:", word)
    start_time = time.time()
    user_input = input().strip()
    end_time = time.time()

    if end_time - start_time > max_time:
        print("Game over!!!!")
    elif user_input.lower() != word:
        print("Incorrect word!")
    else:
        print("Congratulations! You typed the word correctly in", round(end_time - start_time, 2), "seconds.")

if __name__ == "__main__":
    game()
