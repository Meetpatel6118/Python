def create_nested_dict(lst):
    if len(lst) == 1:
        return lst[0]
    else:
        return {lst[0]: create_nested_dict(lst[1:])}

input_list = [1, 2, 3, 4, 5, 6]
output_dict = create_nested_dict(input_list)
print(output_dict)
