from collections import defaultdict

def generate_combinations(word):
    combinations = defaultdict(dict)
    length = len(word)
    for i in range(1, length + 1):
        for j in range(length - i + 1):
            substring = word[j:j+i]
            if substring in combinations[i]:
                combinations[i][substring] += 1
            else:
                combinations[i][substring] = 1
    return combinations

def main():
    user_input = input("Enter a string: ")
    combinations = generate_combinations(user_input)
    print("Output:", combinations)

if __name__ == "__main__":
    main()
