people_list = [['John', 'Doe'], ['Jane'], ['Michael', 'Smith'],['Meet','Patel']]

index = 0

while index < len(people_list):
    names = people_list[index]
    full_name = ' '.join(names)
    print(full_name)
    index += 1
